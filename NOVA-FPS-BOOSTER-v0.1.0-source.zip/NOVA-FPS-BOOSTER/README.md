# NOVA FPS BOOSTER — v0.1.0 starter

Client-side Fabric mod project for Minecraft Java 1.21.11.

## Current status

This is the **project foundation**, not a finished FPS booster yet.

Included:
- Fabric client entrypoint and mod metadata
- Java 21 toolchain
- Minecraft 1.21.11 + Fabric Loader 0.18.1 target
- Initial performance profile model (MAX_FPS / BALANCED / VISUALS)
- Basic configuration read/write helper

Not included yet:
- Automatic render-distance changes
- Adaptive resolution
- Shader-pack modification
- FPS guarantee or benchmark claims

The first milestone deliberately avoids changing graphics settings until the game-version APIs and shader compatibility are tested. This prevents the starter mod from silently damaging a player's settings or causing avoidable crashes.

## Requirements

- JDK 21
- Gradle compatible with Fabric Loom 1.14
- Minecraft Java 1.21.11
- Fabric Loader 0.18.1 or newer

## Build

From this folder, run:

```bash
gradle build
```

The output JAR will be in:

```text
build/libs/nova-fps-booster-0.1.0.jar
```

This archive does not include Gradle Wrapper scripts. Open the folder as a Gradle project in IntelliJ IDEA or VS Code, or use a local Gradle installation.

## Install for testing

Copy the built JAR into the Minecraft instance's `mods` folder. This is a client-only mod. Back up worlds and settings before testing experimental builds.

## Development roadmap

1. Confirm clean launch on vanilla Fabric 1.21.11.
2. Add a configurable low-render-distance profile and restore previous settings.
3. Add adaptive behavior based on sustained frame-time measurements, not single-frame spikes.
4. Test compatibility with Sodium and Iris separately.
5. Investigate shader-specific settings only where the shader exposes safe configuration options.
6. Benchmark on several low-end GPUs, including Unisoc T606 devices.

## Important performance note

A mod cannot make a GPU render a heavy shader beyond its hardware limits. The goal is to reduce unnecessary work and adapt quality gracefully. Results must be measured on each device, shader version, resolution, and world.
