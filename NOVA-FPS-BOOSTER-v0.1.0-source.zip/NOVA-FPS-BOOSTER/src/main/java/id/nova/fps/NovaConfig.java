package id.nova.fps;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Small config helper. The Minecraft config directory will be connected
 * in the next implementation milestone.
 */
public final class NovaConfig {
    private NovaConfig() {}

    public static final String DEFAULT_PROFILE = "MAX_FPS";
    public static final boolean ADAPTIVE_MODE_DEFAULT = true;

    public static Properties load(Path file) {
        Properties properties = new Properties();
        if (Files.isRegularFile(file)) {
            try (InputStream input = Files.newInputStream(file)) {
                properties.load(input);
            } catch (IOException exception) {
                NovaClient.LOGGER.warn("Could not read NOVA config.", exception);
            }
        }
        properties.putIfAbsent("profile", DEFAULT_PROFILE);
        properties.putIfAbsent("adaptiveMode", Boolean.toString(ADAPTIVE_MODE_DEFAULT));
        return properties;
    }

    public static void save(Path file, Properties properties) {
        try {
            Files.createDirectories(file.getParent());
            try (OutputStream output = Files.newOutputStream(file)) {
                properties.store(output, "NOVA FPS BOOSTER configuration");
            }
        } catch (IOException exception) {
            NovaClient.LOGGER.warn("Could not save NOVA config.", exception);
        }
    }
}
