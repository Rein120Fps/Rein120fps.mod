package id.nova.fps;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * NOVA FPS BOOSTER client entrypoint.
 *
 * This first milestone only verifies that the mod loads correctly.
 * Performance changes will be added in measured, device-safe stages.
 */
public final class NovaClient implements ClientModInitializer {
    public static final String MOD_ID = "nova_fps_booster";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info("NOVA FPS BOOSTER v0.1.0 loaded.");
        LOGGER.info("Profile system is being prepared; no graphics settings are changed yet.");
    }
}
