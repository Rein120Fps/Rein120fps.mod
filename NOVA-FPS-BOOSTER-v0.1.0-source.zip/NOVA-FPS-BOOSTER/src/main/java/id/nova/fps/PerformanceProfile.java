package id.nova.fps;

/**
 * Target profiles for later adaptive optimization.
 * These are configuration targets, not guaranteed FPS results.
 */
public enum PerformanceProfile {
    MAX_FPS(6, 4, 0.50),
    BALANCED(8, 5, 0.75),
    VISUALS(10, 6, 1.00);

    private final int renderDistance;
    private final int simulationDistance;
    private final double entityDistanceScale;

    PerformanceProfile(int renderDistance, int simulationDistance, double entityDistanceScale) {
        this.renderDistance = renderDistance;
        this.simulationDistance = simulationDistance;
        this.entityDistanceScale = entityDistanceScale;
    }

    public int renderDistance() {
        return renderDistance;
    }

    public int simulationDistance() {
        return simulationDistance;
    }

    public double entityDistanceScale() {
        return entityDistanceScale;
    }
}
